import React, { Component } from 'react';
import Flexi from './component/Flexi';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.onFlexiSubmit = this.onFlexiSubmit.bind(this);
    this.state.flexiConfig = {

      items: [
        {
          "name": "person_name",
          "label": "Person's Name",
          "type": "TextField",
        },
        {
          "name": "states",
          "label": "Person's state",
          "type": "DropDown",
          "values": [
            "Maharashtra",
            "Kerala",
            "Tamil Nadu"
          ]
        }
      ]
  
    };
  }

  onFlexiSubmit = (data) => {
    console.log("Inside onFlexiSubmit");
    console.log(JSON.stringify(data));
    alert("Data submitted : " +JSON.stringify(data));
  }

  
  render() {
    return (
      <div className="flex-container">
        <Flexi onSubmit={this.onFlexiSubmit} config={this.state.flexiConfig}/>
      </div>
    );
  }
}

export default App;
