import React, { Component } from 'react';

export default class Flexi extends React.Component {
    constructor(props) {
        super(props);
        this.state = { name: '', state: '' };
        this.handleSelectChange = this.handleSelectChange.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }
    handleSelectChange(e) {
        this.setState({ state: e.target.value });
    }
    handleInputChange(e) {
        this.setState({ name: e.target.value });
    }
    onSubmit() {
        var data = {
            name: this.state.name,
            state: this.state.state
        };
        this.props.onSubmit(data);

    }


    render() {

        var getComponent1 = "";
        var getComponent2 = "";
        var config = this.props.config;
        const len = config.items.length;
        for (let i = 0; i < len; i++) {
            if (config.items[i].type == 'TextField') {

                getComponent1 = <div className="label">{config.items[i].label}
                    <input style={{ margin: '10px' }} type="text" name="TextField" value={this.state.name} onChange={this.handleInputChange} />
                </div>

            } else if (config.items[i].type == 'DropDown') {
                this.state.state = config.items[i].values[0];
                getComponent2 = <div className="label">{config.items[i].label}
                    <select className="select" onChange={this.handleSelectChange}>
                        <Opt options={config.items[i].values} />
                    </select>
                </div>

            }
        }


        return (
            <div style={{display:'flex',flexDirection:'column'}}>
                <div style={{alignSelf:'center'}}>Hi from Flexi</div>
                {getComponent1}
                {getComponent2}
                <div className="flex-container">
                <button className="btn" onClick={this.onSubmit}>Submit</button>
                </div>
            </div>
        );
    }
}

class Opt extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            this.props.options.map((option, i) => (
                <React.Fragment key={i}>
                    <option value={option}>{option}</option>
                </React.Fragment>
            ))

        );
    }
}